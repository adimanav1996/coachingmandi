<html>
<head><title>Coaching Mandi</title>
<meta name="keyword" content=""/>
<meta name="discription" content=""/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <script src="jquery.min.js"></script>
    <link rel="stylesheet" href="bootstrap.css">
        <link rel="stylesheet" href="index.css">
<link rel="stylesheet" href="animate.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="bootstrap.js"></script>
    <script src="wow.min.js"></script>
              <script>
              new WOW().init();
              </script>
<link rel="stylesheet" type="text/css" href="img/tech/engine1/style.css" />
<script type="text/javascript" src="img/tech/engine1/jquery.js"></script>
    </head>
    <body>
<nav class="display2 navbar navbar-inverse" style="margin-bottom:0px;">
<div class="container-fluid">
<div class="navbar-header">
<a href="#" class="navbar-brand"><b>Coaching Mandi</b></a>
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#div">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
    </div></div></nav>
        <div class="navbar navbar-inverse container-fluid heading collapse navbar-collapse" id="div" style="margin-bottom:0px;border-radius:0px">
             <div class="text-left"><ul class="nav navbar-nav" type="none">
                 <li><a class="wow slideInLeft" href="index.php"><b>Home</b></a></li>
                 <li><a class="wow slideInLeft" href="about.html"><b>About Us</b></a></li>
                 <li><a class="wow slideInLeft" href="#exam"><b>Exam Notification</b></a></li>
                 <li><a class="wow slideInLeft" href="signupform.php"><b>Coaching</b></a></li>
                 <li><a class="wow slideInLeft" href="signuphostel.php"><b>Hostel</b></a></li>
                </ul></div>
            <div class="text-right"><ul type="none" class="nav navbar-nav" style="float:right">
                <li><a class="wow slideInRight" href="#contact"><b>Contact Us</b></a></li>
                <li><a class="wow slideInRight" href="registration.php"><b>Join Us</b></a></li>
                </ul></div>


        </div>
        <div class="header container-fluid" style="background-color:black">
     <div class="text-center"><img src="logo.jpg">
     </div>
           </div>
<div class="technical container">
    <div class="container" style="color:red;font-size:18px;"><marquee>Hurry Now!!Open Soon!! Advance Booking</marquee></div>
    <div id="wowslider-container1">
<div class="ws_images"><ul>
		<li><img src="data1/images/appathon.jpg" alt="" title="" id="wows1_0"/></li>
		<li><img src="data1/images/chemez.jpg" alt="" title="" id="wows1_1"/></li>
		<li><img src="data1/images/codetrex.jpg" alt="" title="" id="wows1_2"/></li>
		<li><img src="data1/images/crypto.jpg" alt="" title="" id="wows1_3"/></li>
		<li><img src="data1/images/electrade.jpg" alt="" title="" id="wows1_4"/></li>
		<li><img src="data1/images/electromatrix.jpg" alt="" title="" id="wows1_5"/></li>
		<li><img src="data1/images/fumes.jpg" alt="" title="" id="wows1_6"/></li>
		<li><img src="data1/images/junkyard.jpg" alt="" title="" id="wows1_7"/></li>
		<li><img src="data1/images/lfr.jpg" alt="" title="" id="wows1_8"/></li>
		<li><img src="data1/images/nirmaan.jpg" alt="" title="" id="wows1_9"/></li>
		<li><img src="data1/images/pixel.jpg" alt="" title="" id="wows1_10"/></li>
		<li><img src="data1/images/playwithcodes.jpg" alt="" title="" id="wows1_11"/></li>
		<li><img src="data1/images/roboking.jpg" alt="" title="" id="wows1_12"/></li>
		<li><img src="data1/images/roborace.jpg" alt="" title="" id="wows1_13"/></li>
		<li><img src="data1/images/rocketwar.jpg" alt="" title="" id="wows1_14"/></li>
		<li><img src="data1/images/showbuzz.jpg" alt="" title="" id="wows1_15"/></li>
		<li><img src="data1/images/spellbee.jpg" alt="" title="" id="wows1_16"/></li>
		<li><img src="data1/images/stock.jpg" alt="" title="" id="wows1_17"/></li>
		<li><a href="http://wowslider.net"><img src="data1/images/tatva.jpg" alt="jquery image slider" title="" id="wows1_18"/></a></li>
		<li><img src="data1/images/treasur.jpg" alt="" title="" id="wows1_19"/></li>
	</ul></div>
	<div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.net">slider jquery</a> by WOWSlider.com v8.8</div>
<div class="ws_shadow"></div>
</div>
<script type="text/javascript" src="img/tech/engine1/wowslider.js"></script>
<script type="text/javascript" src="img/tech/engine1/script.js"></script>
</div>
<div class="container services">
  <h1 class="text-center">Our Services</h1>
    <div class="row">
    <div class="engineering col-sm-3">
        <div class="header text-center">Engineering Coaching</div>
        <span>Show More</span>
    </div>
    <div class="medical col-sm-3">
    <div class="header text-center">Medical Coaching</div></div>
    <div class="ssc col-sm-3">
    <div class="header text-center">SSC/NDA and other Govt. Exams</div></div>
   
 
    <div class="col-sm-3">
        <div class="header text-center">Hostel</div>
    </div>
    <div class="col-sm-3">
    <div class="header text-center">Rooms</div></div>
    <div id="exam" class="col-sm-3">
    <div class="header text-center">Exam Notification</div></div>
    </div>
</div>

     <div id="contact"class="container-fluid footer">
        <div class="container"><div class="row">
            <div class="box2 col-xs-6">
                <span><img src="logo.jpg" class="img-responsive"></span>
UNIVERSITY INSTITUTE OF ENGINEERING AND TECHNOLOGY<br>
Kalyanpur, Kanpur, Uttar Pradesh, India<br>
Phone Number : +91 9999999999<br>
Mobile Number: +91 9999999999<br>
                Website:<a href="www.uietkanpur.com">www.coachingmandi.com</a></div>
            <div class="box col-xs-3" style="margin-left:25%;">
                <a href="#">Terms and Conditions</a><br>
    <a  href="registration.php">Privacy Policy</a><br>
    <a  href="shedule.html">About Us</a><br>
    <a  href="#">Join Us</a><br>
    <a  href="#">Refund & Cancellation</a><br>
    <a  href="#">Feedback</a><br>
            </div></div>
    </div></div>
        <div class="container-fluid address">
        <div class="text-center">
            @Developer : All Rights Reserved<br>
Developed and Designed by: Aditya Parashar<br>
        </div>
    </div>
    </body>
</html>

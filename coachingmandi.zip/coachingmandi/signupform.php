
<html>
<head><title>Coaching Mandi</title>
<meta name="keyword" content=""/>
<meta name="discription" content=""/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <script src="jquery.min.js"></script>
    <link rel="stylesheet" href="bootstrap.css">
        <link rel="stylesheet" href="index.css">
<link rel="stylesheet" href="animate.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="bootstrap.js"></script>
    <script src="wow.min.js"></script>
              <script>
              new WOW().init();
              </script>
<link rel="stylesheet" type="text/css" href="img/tech/engine1/style.css" />
<script type="text/javascript" src="img/tech/engine1/jquery.js"></script>
    </head>
    <body style="overflow-x:hidden">
<nav class="display2 navbar navbar-inverse" style="margin-bottom:0px;">
<div class="container-fluid">
<div class="navbar-header">
<a href="#" class="navbar-brand"><b>Coaching Mandi</b></a>
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#div">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
    </div></div></nav>
        <div class="navbar navbar-inverse container-fluid heading collapse navbar-collapse" id="div" style="margin-bottom:0px;border-radius:0px">
             <div class="text-left"><ul class="nav navbar-nav" type="none">
                 <li><a class="wow slideInLeft" href="index.php"><b>Home</b></a></li>
                 <li><a class="wow slideInLeft" href="about.html"><b>About Us</b></a></li>
                 <li><a class="wow slideInLeft" href="index.php#exam"><b>Exam Notification</b></a></li>
                 <li><a class="wow slideInLeft" href="signupform.php"><b>Coaching</b></a></li>
                 <li><a class="wow slideInLeft" href="signuphostel.php"><b>Hostel</b></a></li>
                </ul></div>
            <div class="text-right"><ul type="none" class="nav navbar-nav" style="float:right">
                <li><a class="wow slideInRight" href="#contact"><b>Contact Us</b></a></li>
                <li><a class="wow slideInRight" href="registration.php"><b>Join Us</b></a></li>
                </ul></div>


        </div>
        <div class="header container-fluid" style="background-color:black">
     <div class="text-center"><img src="logo.jpg">
     </div>
           </div>    
        <form class="container form-horizontal" action="upload.php" method="post">
  <h1 class="text-center">Registration/Sign Up form for Coachings:</h1>
    <div class="form-group">
      <label class="control-label col-sm-2" for="n1">Name of INSTITUTE</label>
      <div class="col-sm-5">
        <input type="text" class="form-control" id="n1" placeholder="Institution Name" name="institute" required>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="n2">Director of INSTITUTE</label>
      <div class="col-sm-5">
        <input type="text" class="form-control" id="n2" placeholder="Director" name="director" required>
      </div>
    </div>
   <div class="form-group">
      <label class="control-label col-sm-2" for="n3">Contact No.</label>
      <div class="col-sm-5">
        <input type="number" class="form-control" id="n3" placeholder="Mobile No" name="mobile" required>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="n4">Exam of Preperation</label>
      <div class="col-sm-5">
        <input type="text" class="form-control" id="n3" placeholder="Exam for which preperation provided" name="exam" required>
      </div>
    </div>
    <div class="form-group">
     <label class="control-label col-sm-2" for="n4">Coaching established in</label>
     <div class="col-sm-5">
       <input type="text" class="form-control" id="n4" placeholder="Year" name="year">
     </div>
   </div>
   <div class="form-group">
    <label class="control-label col-sm-2" for="n4">Number of Batches take:</label>
    <div class="col-sm-5">
      <input type="text" class="form-control" id="n4" placeholder="Batches" name="batch">
    </div>
  </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="n4">Message about our Coaching:</label>
      <div class="col-sm-5">
          <textarea rows="4" class="form-control" id="n4" placeholder="Message" name="message"></textarea>
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="n4">Upload Photo of Coaching(if any):</label>
      <div class="col-sm-5">
        <input type="file" id="n4"name="file">
      </div>
    </div>
    <div class="form-group">
     <label class="control-label col-sm-2" for="n4">Upload Toppers Photo (if any):</label>
     <div class="col-sm-5">
       <input type="file" id="n4" name="topper">
     </div>
   </div>
    <div class="form-group">
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-default text-center" >Submit</button>
      </div>
    </div>
  </form>
        
     <div id="contact"class="container-fluid footer">
        <div class="container"><div class="row">
            <div class="box2 col-xs-6">
                <span><img src="logo.jpg" class="img-responsive"></span>
UNIVERSITY INSTITUTE OF ENGINEERING AND TECHNOLOGY<br>
Kalyanpur, Kanpur, Uttar Pradesh, India<br>
Phone Number : +91 9999999999<br>
Mobile Number: +91 9999999999<br>
                Website:<a href="www.uietkanpur.com">www.coachingmandi.com</a></div>
            <div class="box col-xs-3" style="margin-left:25%;">
                <a href="#">Terms and Conditions</a><br>
    <a  href="registration.php">Privacy Policy</a><br>
    <a  href="shedule.html">About Us</a><br>
    <a  href="#">Join Us</a><br>
    <a  href="#">Refund & Cancellation</a><br>
    <a  href="#">Feedback</a><br>
            </div></div>
    </div></div>
    </body>
</html>